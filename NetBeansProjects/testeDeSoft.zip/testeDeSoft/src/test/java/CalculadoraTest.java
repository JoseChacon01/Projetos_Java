/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

//import com.mycompany.testedesoft.Calculadora;
//import org.junit.jupiter.api.Test;
//import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author josem
 */
//public class CalculadoraTest {
   // String mesage = "Testando Calculadora";
   // @Test
    
   // public void testSomar() {
     //   System.out.println("Testando metodo somar");
      //  int num1 = 10;
       // int num2= 5;
        
      //  int resultadoEsperado = 17;
        
      //  Calculadora calculadora = new Calculadora();
        
      //  assertEquals(resultadoEsperado, calculadora.somar(num1, num2));
   // }
    
//}
